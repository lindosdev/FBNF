/* Fretboard Notes & Frequencies.
  Copyright (C) 2010-2022  Gary J. Teixeira Jr.

  You can redistribute this program and/or modify
  it under the terms of the Creative Commons
  Attribution-NonCommercial 4.0 International License.
   
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

  You may contact the developer of this program at:  ambientmine@protonmail.com
*/

#include <stdio.h>
#include <string.h> 
int main(void)
{
  printf ("Fretboard Notes & Frequencies.\n Copyright C 2010-2022  Gary J. Teixeira Jr.\n\n You can redistribute this program and/or modify\n it under the terms of the Creative Commons\n Attribution-NonCommercial 4.0 International License.\n\n This program is distributed in the hope that it will be useful,\n but WITHOUT ANY WARRANTY without even the implied warranty of\n MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.\n\n You may contact the developer of this program at  ambientmine at protonmail.com\n");
  printf ("-11 Frets\n    S   4              3              2              1\n\n    0   F1   21.82676  Bb2  29.13524  D#2  38.89087  G#2  51.91309\n    1   F#1  23.12465  B2   30.86771  E2   41.20344  A3   55\n    2   G1   24.49971  C2   32.7032   F2   43.65353  Bb3  58.27047\n    3   G#1  25.95654  C#2  34.64783  F#2  46.2493   B3   61.73541\n    4   A2   27.5      D2   36.7081   G2   48.99943  C3   65.40639\n    5   Bb2  29.13524  D#2  38.89087  G#2  51.91309  C#3  69.29566\n    6   B2   30.86771  E2   41.20344  A3   55        D3   73.41619\n    7   C2   32.7032   F2   43.65353  Bb3  58.27047  D#3  77.78175\n    8   C#2  34.64783  F#2  46.2493   B3   61.73541  E3   82.40689\n    9   D2   36.7081   G2   48.99943  C3   65.40639  F3   87.30706\n    10  D#2  38.89087  G#2  51.91309  C#3  69.29566  F#3  92.49861\n    11  E2   41.20344  A3   55        D3   73.41619  G3   97.99886\n    12  F2   43.65353  Bb3  58.27047  D#3  77.78175  G#3  103.8262\n    13  F#2  46.2493   B3   61.73541  E3   82.40689  A4   110\n    14  G2   48.99943  C3   65.40639  F3   87.30706  Bb4  116.5409\n    15  G#2  51.91309  C#3  69.29566  F#3  92.49861  B4   123.4708\n    16  A3   55        D3   73.41619  G3   97.99886  C4   130.8128\n    17  Bb3  58.27047  D#3  77.78175  G#3  103.8262  C#4  138.5913\n    18  B3   61.73541  E3   82.40689  A4   110       D4   146.8324\n    19  C3   65.40639  F3   87.30706  Bb4  116.5409  D#4  155.5635\n    20  C#2  69.29566  F#3  92.49861  B4   123.4708  E4   164.8324\n    21  D3   73.41619  G3   97.99886  C4   130.8128  F4   174.6141\n    22  D#3  77.78175  G#3  103.8262  C#4  138.5913  F#4  184.9972\n    23  E3   82.40689  A4   110       D4   146.8324  G4   195.9977\n    24  F3   87.30706  Bb4  116.5409  D#4  155.5635  G#4  207.6523\n");
  printf ("\n");
  
  return 0;
}
