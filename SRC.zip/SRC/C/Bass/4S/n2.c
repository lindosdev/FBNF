/* Fretboard Notes & Frequencies.
  Copyright (C) 2010-2022  Gary J. Teixeira Jr.

  You can redistribute this program and/or modify
  it under the terms of the Creative Commons
  Attribution-NonCommercial 4.0 International License.
   
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

  You may contact the developer of this program at:  ambientmine@protonmail.com
*/

#include <stdio.h>
#include <string.h> 
int main(void)
{
  printf ("Fretboard Notes & Frequencies.\n Copyright C 2010-2022  Gary J. Teixeira Jr.\n\n You can redistribute this program and/or modify\n it under the terms of the Creative Commons\n Attribution-NonCommercial 4.0 International License.\n\n This program is distributed in the hope that it will be useful,\n but WITHOUT ANY WARRANTY without even the implied warranty of\n MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.\n\n You may contact the developer of this program at  ambientmine at protonmail.com\n");
  printf ("-2 Frets\n    S   4              3              2              1\n\n    0   D2   36.7081   G2   48.99943  C3   65.40639  F3   87.30706\n    1   D#2  38.89087  G#2  51.91309  C#3  69.29566  F#3  92.49861\n    2   E2   41.20344  A3   55        D3   73.41619  G3   97.99886\n    3   F2   43.65353  Bb3  58.27047  D#3  77.78175  G#3  103.8262\n    4   F#2  46.2493   B3   61.73541  E3   82.40689  A4   110\n    5   G2   48.99943  C3   65.40639  F3   87.30706  Bb4  116.5409\n    6   G#2  51.91309  C#3  69.29566  F#3  92.49861  B4   123.4708\n    7   A3   55        D3   73.41619  G3   97.99886  C4   130.8128\n    8   Bb3  58.27047  D#3  77.78175  G#3  103.8262  C#4  138.5913\n    9   B3   61.73541  E3   82.40689  A4   110       D4   146.8324\n    10  C3   65.40639  F3   87.30706  Bb4  116.5409  D#4  155.5635\n    11  C#2  69.29566  F#3  92.49861  B4   123.4708  E4   164.8324\n    12  D3   73.41619  G3   97.99886  C4   130.8128  F4   174.6141\n    13  D#3  77.78175  G#3  103.8262  C#4  138.5913  F#4  184.9972\n    14  E3   82.40689  A4   110       D4   146.8324  G4   195.9977\n    15  F3   87.30706  Bb4  116.5409  D#4  155.5635  G#4  207.6523\n    16  F#3  92.49861  B4   123.4708  E4   164.8324  A5   220\n    17  G3   97.99886  C4   130.8128  F4   174.6141  Bb5  233.0819\n    18  G#3  103.8262  C#4  138.5913  F#4  184.9972  B5   246.9417\n    19  A4   110       D4   146.8324  G4   195.9977  C5   261.6256\n    20  Bb4  116.5409  D#4  155.5635  G#4  207.6523  C#5  277.1826\n    21  B4   123.4708  E4   164.8324  A5   220       D5   293.6648\n    22  C4   130.8128  F4   174.6141  Bb5  233.0819  D#5  311.127\n    23  C#4  138.5913  F#4  184.9972  B5   246.9417  E5   329.6276\n    24  D4   146.8324  G4   195.9977  C5   261.6256  F5   349.2282\n");
  printf ("\n");
  
  return 0;
}
