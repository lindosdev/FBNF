/* Fretboard Notes & Frequencies.
  Copyright (C) 2010-2022  Gary J. Teixeira Jr.

  You can redistribute this program and/or modify
  it under the terms of the Creative Commons
  Attribution-NonCommercial 4.0 International License.
   
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

  You may contact the developer of this program at:  ambientmine@protonmail.com
*/

#include <stdio.h>
#include <string.h> 
int main(void)
{
  printf ("Fretboard Notes & Frequencies.\n Copyright C 2010-2022  Gary J. Teixeira Jr.\n\n You can redistribute this program and/or modify\n it under the terms of the Creative Commons\n Attribution-NonCommercial 4.0 International License.\n\n This program is distributed in the hope that it will be useful,\n but WITHOUT ANY WARRANTY without even the implied warranty of\n MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.\n\n You may contact the developer of this program at  ambientmine at protonmail.com\n");
  printf ("+50 Frets\n    S   4              3              2              1\n\n    0   G6   783.9909  B7   987.7666  E7   1318.51   A8   1760\n    1   G#6  830.6094  C7   1046.502  F7   1396.913  Bb8  1864.655\n    2   A7   880       C#7  1108.731  F#7  1479.978  B8   1975.533\n    3   Bb7  932.3275  D7   1174.659  G7   1567.982  C8   2093.005\n    4   B7   987.7666  D#7  1244.508  G#7  1661.219  C#8  2217.461\n    5   C7   1046.502  E7   1318.51   A8   1760      D8   2349.318\n    6   C#7  1108.731  F7   1396.913  Bb8  1864.655  D#8  2489.016\n    7   D7   1174.659  F#7  1479.978  B8   1975.533  E8   2637.02\n    8   D#7  1244.508  G7   1567.982  C8   2093.005  F8   2793.826\n    9   E7   1318.51   G#7  1661.219  C#8  2217.461  F#8  2959.955\n    10  F7   1396.913  A8   1760      D8   2349.318  G8   3135.963\n    11  F#7  1479.978  Bb8  1864.655  D#8  2489.016  G#8  3322.438\n    12  G7   1567.982  B8   1975.533  E8   2637.02   A9   3520\n    13  G#7  1661.219  C8   2093.005  F8   2793.826  Bb9  3729.31\n    14  A8   1760      C#8  2217.461  F#8  2959.955  B9   2951.066\n    15  Bb8  1864.655  D8   2349.318  G8   3135.963  C9   4186.009\n    16  B8   1975.533  D#8  2489.016  G#8  3322.438  C#9  4434.922\n    17  C8   2093.005  E8   2637.02   A9   3520      D9   4698.636\n    18  C#8  2217.461  F8   2793.826  Bb9  3729.31   D#9  4978.032\n    19  D8   2349.318  F#8  2959.955  B9   2951.066  E9   5274.041\n    20  D#8  2489.016  G8   3135.963  C9   4186.009  F9   5587.652\n    21  E8   2637.02   G#8  3322.438  C#9  4434.922  F#9  5919.911\n    22  F8   2793.826  A9   3520      D9   4698.636  G9   6271.927\n    23  F#8  2959.955  Bb9  3729.31   D#9  4978.032  G#9  6644.875\n    24  G8   3135.963  B9   2951.066  E9   5274.041  A10  7040\n");
  printf ("\n");
  
  return 0;
}
