/* Fretboard Notes & Frequencies.
  Copyright (C) 2010-2022  Gary J. Teixeira Jr.

  You can redistribute this program and/or modify
  it under the terms of the Creative Commons
  Attribution-NonCommercial 4.0 International License.
   
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

  You may contact the developer of this program at:  ambientmine@protonmail.com
*/

#include <stdio.h>
#include <string.h> 
int main(void)
{
  printf ("Fretboard Notes & Frequencies.\n Copyright C 2010-2022  Gary J. Teixeira Jr.\n\n You can redistribute this program and/or modify\n it under the terms of the Creative Commons\n Attribution-NonCommercial 4.0 International License.\n\n This program is distributed in the hope that it will be useful,\n but WITHOUT ANY WARRANTY without even the implied warranty of\n MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.\n\n You may contact the developer of this program at  ambientmine at protonmail.com\n");
  printf ("+11 Frets\n    S   6              5              4              3              2              1\n\n    0   D#3  77.78175  G#3  103.8262  C#4  138.5913  F#4  184.9972  Bb5  233.0819  D#5  311.127\n    1   E3   82.40689  A4   110       D4   146.8324  G4   195.9977  B5   246.9417  E5   329.6276\n    2   F3   87.30706  Bb4  116.5409  D#4  155.5635  G#4  207.6523  C5   261.6256  F5   349.2282\n    3   F#3  92.49861  B4   123.4708  E4   164.8324  A5   220       C#5  277.1826  F#5  369.9944\n    4   G3   97.99886  C4   130.8128  F4   174.6141  Bb5  233.0819  D5   293.6648  G5   391.9954\n    5   G#3  103.8262  C#4  138.5913  F#4  184.9972  B5   246.9417  D#5  311.127   G#5  415.3047\n    6   A4   110       D4   146.8324  G4   195.9977  C5   261.6256  E5   329.6276  A6   440\n    7   Bb4  116.5409  D#4  155.5635  G#4  207.6523  C#5  277.1826  F5   349.2282  Bb6  466.1638\n    8   B4   123.4708  E4   164.8324  A5   220       D5   293.6648  F#5  369.9944  B6   493.8833\n    9   C4   130.8128  F4   174.6141  Bb5  233.0819  D#5  311.127   G5   391.9954  C6   523.2511\n    10  C#4  138.5913  F#4  184.9972  B5   246.9417  E5   329.6276  G#5  415.3047  C#6  554.3653\n    11  D4   146.8324  G4   195.9977  C5   261.6256  F5   349.2282  A6   440       D6   587.3295\n    12  D#4  155.5635  G#4  207.6523  C#5  277.1826  F#5  369.9944  Bb6  466.1638  D#6  622.254\n    13  E4   164.8324  A5   220       D5   293.6648  G5   391.9954  B6   493.8833  E6   659.2551\n    14  F4   174.6141  Bb5  233.0819  D#5  311.127   G#5  415.3047  C6   523.2511  F6   698.4565\n    15  G4   184.9972  B5   246.9417  E5   329.6276  A6   440       C#6  554.3653  F#6  739.9888\n    16  G#4  195.9977  C5   261.6256  F5   349.2282  Bb6  466.1638  D6   587.3295  G6   783.9909\n    17  A5   220       C#5  277.1826  F#5  369.9944  B6   493.8833  D#6  622.254   G#6  830.6094\n    18  Bb5  233.0819  D5   293.6648  G5   391.9954  C6   523.2511  E6   659.2551  A7   880\n    19  B5   246.9417  D#5  311.127   G#5  415.3047  C#6  554.3653  F6   698.4565  Bb7  932.3275\n    20  C5   261.6256  E5   329.6276  A6   440       D6   587.3295  F#6  739.9888  B7   987.7666\n    21  C#5  277.1826  F5   349.2282  Bb6  466.1638  D#6  622.254   G6   783.9909  C7   1046.502\n    22  D5   293.6648  F#5  369.9944  B6   493.8833  E6   659.2551  G#6  830.6094  C#7  1108.731\n    23  D#5  311.127   G5   391.9954  C6   523.2511  F6   698.4565  A7   880       D7   1174.659\n    24  E5   329.6276  G#5  415.3047  C#6  554.3653  F#6  739.9888  Bb7  932.3275  D#7  1244.508\n");
  printf ("\n");
  
  return 0;
}
