/* Fretboard Notes & Frequencies.
  Copyright (C) 2010-2022  Gary J. Teixeira Jr.

  You can redistribute this program and/or modify
  it under the terms of the Creative Commons
  Attribution-NonCommercial 4.0 International License.
   
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

  You may contact the developer of this program at:  ambientmine@protonmail.com
*/

#include <stdio.h>
#include <string.h> 
int main(void)
{
  printf ("Fretboard Notes & Frequencies.\n Copyright C 2010-2022  Gary J. Teixeira Jr.\n\n You can redistribute this program and/or modify\n it under the terms of the Creative Commons\n Attribution-NonCommercial 4.0 International License.\n\n This program is distributed in the hope that it will be useful,\n but WITHOUT ANY WARRANTY without even the implied warranty of\n MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.\n\n You may contact the developer of this program at  ambientmine at protonmail.com\n");
printf ("-7 Frets\n    S   5              4              3              2              1\n\n    0   E1   20.60172  A2   27.5      D2   36.7081   G2   48.99943  B3   61.73541\n    1   F1   21.82676  Bb2  29.13524  D#2  38.89087  G#2  51.91309  C3   65.40639\n    2   F#1  23.12465  B2   30.86771  E2   41.20344  A3   55        C#3  69.29566\n    3   G1   24.49971  C2   32.7032   F2   43.65353  Bb3  58.27047  D3   73.41619\n    4   G#1  25.95654  C#2  34.64783  F#2  46.2493   B3   61.73541  D#3  77.78175\n    5   A2   27.5      D2   36.7081   G2   48.99943  C3   65.40639  E3   82.40689\n    6   Bb2  29.13524  D#2  38.89087  G#2  51.91309  C#3  69.29566  F3   87.30706\n    7   B2   30.86771  E2   41.20344  A3   55        D3   73.41619  F#3  92.49861\n    8   C2   32.7032   F2   43.65353  Bb3  58.27047  D#3  77.78175  G3   97.99886\n    9   C#2  34.64783  F#2  46.2493   B3   61.73541  E3   82.40689  G#3  103.8262\n    10  D2   36.7081   G2   48.99943  C3   65.40639  F3   87.30706  A4   110\n    11  D#2  38.89087  G#2  51.91309  C#3  69.29566  F#3  92.49861  Bb4  116.5409\n    12  E2   41.20344  A3   55        D3   73.41619  G3   97.99886  B4   123.4708\n    13  F2   43.65353  Bb3  58.27047  D#3  77.78175  G#3  103.8262  C4   130.8128\n    14  F#2  46.2493   B3   61.73541  E3   82.40689  A4   110       C#4  138.5913\n    15  G2   48.99943  C3   65.40639  F3   87.30706  Bb4  116.5409  D4   146.8324\n    16  G#2  51.91309  C#3  69.29566  F#3  92.49861  B4   123.4708  D#4  155.5635\n    17  A3   55        D3   73.41619  G3   97.99886  C4   130.8128  E4   164.8324\n    18  Bb3  58.27047  D#3  77.78175  G#3  103.8262  C#4  138.5913  F4   174.6141\n    19  B3   61.73541  E3   82.40689  A4   110       D4   146.8324  F#4  184.9972\n    20  C3   65.40639  F3   87.30706  Bb4  116.5409  D#4  155.5635  G4   195.9977\n    21  C#2  69.29566  F#3  92.49861  B4   123.4708  E4   164.8324  G#4  207.6523\n    22  D3   73.41619  G3   97.99886  C4   130.8128  F4   174.6141  A5   220\n    23  D#3  77.78175  G#3  103.8262  C#4  138.5913  F#4  184.9972  Bb5  233.0819\n    24  E3   82.40689  A4   110       D4   146.8324  G4   195.9977  B5   246.9417\n");
  printf ("\n");
  
  return 0;
}
