/* Fretboard Notes & Frequencies.
  Copyright (C) 2010-2022  Gary J. Teixeira Jr.

  You can redistribute this program and/or modify
  it under the terms of the Creative Commons
  Attribution-NonCommercial 4.0 International License.
   
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

  You may contact the developer of this program at:  ambientmine@protonmail.com
*/

#include <stdio.h>
#include <string.h> 
int main(void)
{
  printf ("Fretboard Notes & Frequencies.\n Copyright C 2010-2022  Gary J. Teixeira Jr.\n\n You can redistribute this program and/or modify\n it under the terms of the Creative Commons\n Attribution-NonCommercial 4.0 International License.\n\n This program is distributed in the hope that it will be useful,\n but WITHOUT ANY WARRANTY without even the implied warranty of\n MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.\n\n You may contact the developer of this program at  ambientmine at protonmail.com\n");
  printf ("+28 Frets\n    S   6              5              4              3              2              1\n\n    0   A6   440       C#6  554.3653  F#6  739.9888  B7   987.7666  D#7  1244.508  A8   1760\n    1   Bb6  466.1638  D6   587.3295  G6   783.9909  C7   1046.502  E7   1318.51   Bb8  1864.655\n    2   B6   493.8833  D#6  622.254   G#6  830.6094  C#7  1108.731  F7   1396.913  B8   1975.533\n    3   C6   523.2511  E6   659.2551  A7   880       D7   1174.659  F#7  1479.978  C8   2093.005\n    4   C#6  554.3653  F6   698.4565  Bb7  932.3275  D#7  1244.508  G7   1567.982  C#8  2217.461\n    5   D6   587.3295  F#6  739.9888  B7   987.7666  E7   1318.51   G#7  1661.219  D8   2349.318\n    6   D#6  622.254   G6   783.9909  C7   1046.502  F7   1396.913  A8   1760      D#8  2489.016\n    7   E6   659.2551  G#6  830.6094  C#7  1108.731  F#7  1479.978  Bb8  1864.655  E8   2637.02\n    8   F6   698.4565  A7   880       D7   1174.659  G7   1567.982  B8   1975.533  F8   2793.826\n    9   F#6  739.9888  Bb7  932.3275  D#7  1244.508  G#7  1661.219  C8   2093.005  F#8  2959.955\n    10  G6   783.9909  B7   987.7666  E7   1318.51   A8   1760      C#8  2217.461  G8   3135.963\n    11  G#6  830.6094  C7   1046.502  F7   1396.913  Bb8  1864.655  D8   2349.318  G#8  3322.438\n    12  A7   880       C#7  1108.731  F#7  1479.978  B8   1975.533  D#8  2489.016  A9   3520\n    13  Bb7  932.3275  D7   1174.659  G7   1567.982  C8   2093.005  E8   2637.02   Bb9  3729.31\n    14  B7   987.7666  D#7  1244.508  G#7  1661.219  C#8  2217.461  F8   2793.826  B9   2951.066\n    15  C7   1046.502  E7   1318.51   A8   1760      D8   2349.318  F#8  2959.955  C9   4186.009\n    16  C#7  1108.731  F7   1396.913  Bb8  1864.655  D#8  2489.016  G8   3135.963  C#9  4434.922\n    17  D7   1174.659  F#7  1479.978  B8   1975.533  E8   2637.02   G#8  3322.438  D9   4698.636\n    18  D#7  1244.508  G7   1567.982  C8   2093.005  F8   2793.826  A9   3520      D#9  4978.032\n    19  E7   1318.51   G#7  1661.219  C#8  2217.461  F#8  2959.955  Bb9  3729.31   E9   5274.041\n    20  F7   1396.913  A8   1760      D8   2349.318  G8   3135.963  B9   2951.066  F9   5587.652\n    21  F#7  1479.978  Bb8  1864.655  D#8  2489.016  G#8  3322.438  C9   4186.009  F#9  5919.911\n    22  G7   1567.982  B8   1975.533  E8   2637.02   A9   3520      C#9  4434.922  G9   6271.927\n    23  G#7  1661.219  C8   2093.005  F8   2793.826  Bb9  3729.31   D9   4698.636  G#9  6644.875\n    24  A8   1760      C#8  2217.461  F#8  2959.955  B9   2951.066  D#9  4978.032  A10  7040\n");
  printf ("\n");
  
  return 0;
}
