#!/bin/bash
#
#  Fretboard Notes & Frequencies
#  Copyright (C) 2010-2022  Gary J. Teixeira Jr.
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#  You may contact the developer of this program at: ambientmine@protonmail.com
#
# Global Declarations
SCRIPT=${0##*/} # SCRIPT is the name of this script
CODE=0 # user's input variable
#
# GNU GPL Version 3 Info
printf "%b\n" "Fretboard Notes & Frequencies
Copyright (C) 2010-2022  Gary J. Teixeira Jr.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

You may contact the developer of this program at: ambientmine@protonmail.com"
sleep 10
clear
#
# FOURTH FRET OF 3rd STRING = OPEN 2nd STRING (Guitar)
#
# Read user input, display output based on code entered
read -p "Please Select an option :"  CODE
printf "%s\n\n" "6-String Guitar:"
printf "%s\n" "1. 2. 3. ..."
printf "\n"  
if [ "$CODE" =  1 ]
then
	clear
    printf "%s\n" "Option 1"
elif [ "$CODE" =  2 ]
then
    clear
    printf "%s\n" "Option 2"
else
    printf "%s\n" "Code not implemeted yet (or wrong code)"
fi
    
# Cleanup
exit 0 # all is well
